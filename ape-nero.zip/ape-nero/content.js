// APE → Nero player.
// When illmind says "Ape, next one", "Ape, play it" or "Ape, pause it", his control page raises a signal. This script,
// running on his own open Nero live tab, sees the signal and clicks Nero's own button, exactly as he would with the mouse.
//
// What it does NOT do: it never calls Nero's servers, never reads his account, and never presses anything except the
// Next button and the round Play/Pause button between Previous and Next. If Nero ever renames or moves those buttons,
// this stops pressing and says so; nothing else can happen.
//
// Safety: only one tab may press (the signal server hands each request to the first tab that asks), a request older
// than a few seconds is ignored, and the chip in the corner turns it off with one click.
(() => {
  const SIG = "https://zlujvgqnvrhxrhkefgqr.supabase.co/functions/v1/nero-next";
  const CHIP = "ape-next-chip";
  if (document.getElementById(CHIP)) return;                       // already running on this page
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const nextButton = () => document.querySelector('button[aria-label="Next submission"]')
    || (document.querySelector("svg.lucide-skip-forward") ? document.querySelector("svg.lucide-skip-forward").closest("button") : null);
  const prevButton = () => document.querySelector('button[aria-label="Previous submission"]')
    || (document.querySelector("svg.lucide-skip-back") ? document.querySelector("svg.lucide-skip-back").closest("button") : null);
  function playButton() {                                          // the round button that sits between Previous and Next
    const nx = nextButton(); if (!nx || !nx.parentElement) return null;
    const pv = prevButton();
    return [...nx.parentElement.querySelectorAll("button")].find(b => b !== nx && b !== pv) || null;
  }
  const describe = b => { const svg = b.querySelector("svg"); return ((b.getAttribute("aria-label") || "") + " " + (b.getAttribute("title") || "") + " " + ((svg && svg.getAttribute("class")) || "")).toLowerCase(); };
  function playState(b) {                                          // "playing" | "paused" | "loading" | "unknown", read from what the button shows
    const d = describe(b);
    if (/loader|loading|spinner/.test(d)) return "loading";
    if (/lucide-pause|\bpause/.test(d)) return "playing";         // it offers Pause, so the song is playing
    if (/lucide-play|\bplay|\bresume/.test(d)) return "paused";
    const a = document.querySelector("audio, video"); if (a) return a.paused ? "paused" : "playing";
    return "unknown";
  }

  let on = true; try { on = localStorage.getItem("ape_next_off") !== "1"; } catch (e) {}
  let seen = null, last = "";

  const chip = document.createElement("div"); chip.id = CHIP; chip.title = "Click to turn Ape's Nero controls on or off";
  chip.style.cssText = "position:fixed;left:14px;bottom:14px;z-index:2147483647;padding:7px 11px;border-radius:999px;cursor:pointer;user-select:none;" +
    "font:700 11px/1 ui-monospace,'SF Mono',Menlo,Courier,monospace;letter-spacing:1.4px;background:#14141a;border:1px solid #2a2a36;color:#8a8a95;box-shadow:0 6px 20px rgba(0,0,0,.45)";
  function paint(note, colour) {
    const here = !!nextButton();
    chip.style.display = here || note ? "block" : "none";          // only shows on the page that has the player buttons
    chip.textContent = note || (on ? "APE · NERO READY" : "APE · NERO OFF");
    chip.style.color = colour || (on ? "#5fd38d" : "#8a8a95"); chip.style.borderColor = colour || (on ? "#2d5a41" : "#2a2a36");
  }
  chip.onclick = () => { on = !on; seen = null; try { localStorage.setItem("ape_next_off", on ? "0" : "1"); } catch (e) {} paint(); };
  document.documentElement.appendChild(chip);

  const post = body => fetch(SIG, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) }).then(r => r.json());
  async function act(cmd) {                                        // -> [pressed or already as asked, why]
    if (cmd === "next") {
      const b = nextButton();
      if (!b) return [false, "could not find the Next button on the Nero page"];
      if (b.disabled) return [false, "Next is switched off on the Nero page right now"];
      b.click(); return [true, ""];
    }
    const b = playButton();
    if (!b) return [false, "could not find the Play button on the Nero page"];
    let st = playState(b);
    for (let i = 0; st === "loading" && i < 16; i++) { await sleep(250); st = playState(b); }   // give a song up to 4 seconds to finish loading
    const want = cmd === "play" ? "playing" : "paused";
    if (st === want) return [true, "it was already " + want];
    if (st === "loading") return [false, "the song is still loading in Nero"];
    if (st === "unknown") return [false, "could not tell if the song is playing: " + describe(b).replace(/[^a-z0-9 -]/g, " ").trim().slice(0, 50)];
    if (b.disabled) return [false, "Play is switched off on the Nero page right now"];
    b.click(); return [true, ""];
  }
  async function press(n, cmd) {
    const c = await post({ claim: n });
    if (!c || !c.yours) return;                                    // another tab has it, or it is too old
    let ok = false, why = "";
    try { [ok, why] = await act(cmd); } catch (e) { why = "the Nero page threw an error"; }
    post({ ack: { n, ok, why } }).catch(() => {});
    paint(ok ? "APE PRESSED " + cmd.toUpperCase() : "APE COULD NOT " + cmd.toUpperCase(), ok ? "#e0a243" : "#e8705f"); last = String(Date.now());
    const mine = last; setTimeout(() => { if (last === mine) paint(); }, 4000);
  }
  (async function loop() {
    for (;;) {
      try {
        if (!on || !nextButton()) { seen = null; paint(); await sleep(2000); continue; }   // off, or not on the live page: forget where we were, so nothing old is replayed later
        const j = await (await fetch(SIG + "?n=" + (seen === null ? -1 : seen) + "&wait=" + (seen === null ? 0 : 20) + "&t=" + Date.now(), { cache: "no-store" })).json();
        if (!j.ok) throw new Error("bad reply");
        if (seen === null) { seen = j.n; paint(); }                // first look: never act on a request that was made before this tab was listening
        else if (j.n !== seen) { seen = j.n; if (on && j.age !== null && j.age < 10000 && ["next", "play", "pause"].includes(j.cmd)) await press(j.n, j.cmd); }
      } catch (e) { paint("APE · NERO OFFLINE", "#e8705f"); await sleep(3000); }
      await sleep(40);
    }
  })();
  window.__apeNext = { nextButton, playButton, playState };       // for testing in the console
})();
